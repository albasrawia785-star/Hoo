import React, { useEffect, useState } from 'react';
import { Cloud, CloudCheck, CloudOff, RefreshCw, LogIn, LogOut, ShieldCheck } from 'lucide-react';
import {
  DriveSyncStatus,
  getDriveSyncStatus,
  subscribeDriveSyncStatus,
  signInGoogleDrive,
  signOutGoogleDrive,
} from '../services/googleDriveSync';
import { User } from '../types';
import { isLocalAccount } from '../utils/userUtils';
import { getLocalSession } from '../services/turso';

interface GoogleDriveSyncBadgeProps {
  userId?: number;
  currentUser?: User | null;
  compact?: boolean;
}

export const GoogleDriveSyncBadge: React.FC<GoogleDriveSyncBadgeProps> = ({
  currentUser,
  userId,
  compact = false,
}) => {
  const activeUser = currentUser || getLocalSession();
  const isLocal = isLocalAccount(activeUser);

  const [status, setStatus] = useState<DriveSyncStatus>('disabled');
  const [lastSynced, setLastSynced] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!isLocal) return;

    const unsub = subscribeDriveSyncStatus((newStatus, lastSyncTime) => {
      setStatus(newStatus);
      if (lastSyncTime) setLastSynced(lastSyncTime);
      const isEnabled = localStorage.getItem('gdrive_sync_enabled') === 'true';
      const userMeta = getDriveSyncStatus().user;
      if (isEnabled && userMeta?.email) {
        setUserEmail(userMeta.email);
      } else if (!isEnabled) {
        setUserEmail(null);
      }
    });

    const isEnabled = localStorage.getItem('gdrive_sync_enabled') === 'true';
    const userMeta = getDriveSyncStatus().user;
    if (isEnabled && userMeta?.email) {
      setUserEmail(userMeta.email);
    } else {
      setUserEmail(null);
    }

    return unsub;
  }, [isLocal]);

  // Only render for local accounts
  if (!isLocal) {
    return null;
  }

  const handleConnect = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const res = await signInGoogleDrive();
      if (res?.user?.email) {
        setUserEmail(res.user.email);
      }
    } catch (err: any) {
      console.error('Failed to connect Google Drive:', err);
      const msg = err?.message || 'تعذر الاتصال بـ Google Drive';
      setErrorMessage(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const [isConfirmingDisconnect, setIsConfirmingDisconnect] = useState(false);

  const handleDisconnect = async () => {
    setIsLoading(true);
    setIsConfirmingDisconnect(false);
    try {
      await signOutGoogleDrive();
      setUserEmail(null);
      setStatus('disabled');
    } catch (err) {
      console.error('Error disconnecting Google Drive:', err);
    } finally {
      setIsLoading(false);
    }
  };

  if (compact) {
    if (status === 'synced') {
      return (
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-medium">
          <CloudCheck className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
          <span>مُتزامن تلقائياً مع Drive</span>
          {lastSynced && <span className="text-[10px] opacity-75">({lastSynced})</span>}
        </div>
      );
    }

    if (status === 'syncing') {
      return (
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-medium">
          <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-400" />
          <span>جاري حفظ التعديلات سحابياً...</span>
        </div>
      );
    }

    if (status === 'offline_queued') {
      return (
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 text-xs font-medium">
          <CloudOff className="w-3.5 h-3.5 text-amber-400" />
          <span>محفوظ محلياً (سينتظر الإنترنت)</span>
        </div>
      );
    }

    return (
      <button
        onClick={handleConnect}
        disabled={isLoading}
        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-medium transition cursor-pointer"
        title="تفعيل المزامنة السحابية الحية مع Google Drive"
      >
        <Cloud className="w-3.5 h-3.5 text-emerald-400" />
        <span>ربط Google Drive</span>
      </button>
    );
  }

  // Full detailed card view (e.g. inside BackupRestoreSection or Settings)
  return (
    <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-100 shadow-sm space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/15 flex items-center justify-center border border-emerald-500/30">
            <Cloud className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
              مزامنة Google Drive السحابية التلقائية
              <ShieldCheck className="w-4 h-4 text-emerald-400 inline" />
            </h4>
            <p className="text-xs text-slate-400">
              حفظ ومزامنة شجرة الحسابات والديون والأقساط تلقائياً وفي الخلفية على حسابك الشخصي في Google Drive مباشرة.
            </p>
          </div>
        </div>

        {userEmail ? (
          isConfirmingDisconnect ? (
            <div className="flex items-center gap-1.5 animate-in fade-in duration-150">
              <button
                onClick={handleDisconnect}
                disabled={isLoading}
                className="px-2.5 py-1 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition shadow-xs flex items-center gap-1 cursor-pointer"
              >
                تأكيد الفصل
              </button>
              <button
                onClick={() => setIsConfirmingDisconnect(false)}
                className="px-2 py-1 text-xs text-slate-400 hover:text-slate-200 bg-slate-800 rounded-lg cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsConfirmingDisconnect(true)}
              disabled={isLoading}
              className="px-3 py-1.5 text-xs font-medium text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 rounded-lg transition flex items-center gap-1 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              فصل الربط
            </button>
          )
        ) : (
          <button
            onClick={handleConnect}
            disabled={isLoading}
            className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition shadow-sm flex items-center gap-1.5 cursor-pointer"
          >
            <LogIn className="w-4 h-4" />
            تفعيل المزامنة التلقائية
          </button>
        )}
      </div>

      {errorMessage && (
        <div className="mt-2 p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2 whitespace-pre-line animate-in fade-in duration-200">
          <i className="fa-solid fa-triangle-exclamation text-rose-400 mt-0.5 shrink-0"></i>
          <div className="flex-1">
            <span className="font-bold">تنبيه:</span> {errorMessage}
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-slate-400 hover:text-white p-0.5 cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-xs"></i>
          </button>
        </div>
      )}

      {userEmail && (
        <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs text-slate-300 gap-2">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">الحساب المرتبط:</span>
            <span className="font-mono text-emerald-400 font-medium">{userEmail}</span>
          </div>

          <div className="flex items-center gap-2">
            {status === 'synced' && (
              <span className="flex items-center gap-1 text-emerald-400 font-medium">
                <CloudCheck className="w-4 h-4" />
                متزامن سحابياً {lastSynced ? `(${lastSynced})` : ''}
              </span>
            )}
            {status === 'syncing' && (
              <span className="flex items-center gap-1 text-blue-400 font-medium animate-pulse">
                <RefreshCw className="w-4 h-4 animate-spin" />
                جاري رفع أحدث المعاملات...
              </span>
            )}
            {status === 'offline_queued' && (
              <span className="flex items-center gap-1 text-amber-400 font-medium">
                <CloudOff className="w-4 h-4" />
                غير متصل بالشبكة - سيتم الحفظ فور الاتصال
              </span>
            )}
            {(status === 'idle' || status === 'disabled') && (
              <span className="flex items-center gap-1 text-slate-400 font-medium">
                جاهز للمزامنة التلقائية
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
