import { Debtor, DebtorTransaction, InstallmentRecord, InstallmentPayment, Supplier, SupplierTransaction } from '../types';
import { getIdbDebtors, saveIdbDebtors, getIdbInstallments, saveIdbInstallments, getIdbSuppliers, saveIdbSuppliers } from './idb';
import { getLocalDebtors, setLocalDebtors, getLocalInstallments, setLocalInstallments, getLocalSuppliers, setLocalSuppliers } from './turso';

// Direct Google OAuth 2.0 Client ID (No Firebase Required)
const GOOGLE_CLIENT_ID = '1095593246404-8m4uiaskkdrr8s5j4sonuijbij28dgvb.apps.googleusercontent.com';

const DRIVE_SCOPES = [
  'https://www.googleapis.com/auth/drive.appdata',
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
].join(' ');

const BACKUP_FILENAME = 'daftardebts_ledger_v2.json';

export type DriveSyncStatus = 'disabled' | 'idle' | 'syncing' | 'synced' | 'offline_queued' | 'error';

export interface DriveUserInfo {
  email: string;
  name?: string;
  picture?: string;
}

let cachedAccessToken: string | null = null;
let currentDriveUser: DriveUserInfo | null = null;
let syncStatus: DriveSyncStatus = 'disabled';
let syncStatusListeners: Array<(status: DriveSyncStatus, lastSyncedAt?: string | null) => void> = [];
let lastSyncedAt: string | null = null;
let debounceTimer: ReturnType<typeof setTimeout> | null = null;
let isSyncing = false;

// Dynamic loader for Google Identity Services script
function loadGsiScript(): Promise<void> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined') return resolve();
    if ((window as any).google?.accounts?.oauth2) {
      return resolve();
    }
    const existing = document.getElementById('google-gsi-client-script');
    if (existing) {
      existing.addEventListener('load', () => resolve());
      existing.addEventListener('error', () => resolve());
      return;
    }
    const script = document.createElement('script');
    script.id = 'google-gsi-client-script';
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.onload = () => resolve();
    script.onerror = () => resolve();
    document.head.appendChild(script);
  });
}

// Register status listener
export function subscribeDriveSyncStatus(
  listener: (status: DriveSyncStatus, lastSyncedAt?: string | null) => void
) {
  syncStatusListeners.push(listener);
  listener(syncStatus, lastSyncedAt);
  return () => {
    syncStatusListeners = syncStatusListeners.filter((l) => l !== listener);
  };
}

function notifyStatus(status: DriveSyncStatus) {
  syncStatus = status;
  syncStatusListeners.forEach((l) => l(syncStatus, lastSyncedAt));
}

export function getDriveSyncStatus() {
  return { status: syncStatus, lastSyncedAt, user: currentDriveUser };
}

/**
 * Initialize Drive Auth on app start
 */
export function initGoogleDriveAuth(
  onUserChanged?: (user: DriveUserInfo | null) => void
) {
  loadGsiScript().catch(() => {});

  try {
    const isEnabled = localStorage.getItem('gdrive_sync_enabled') === 'true';
    const savedToken = localStorage.getItem('gdrive_access_token');
    const expiresAt = Number(localStorage.getItem('gdrive_token_expires_at') || '0');
    const savedUserJson = localStorage.getItem('gdrive_user_info');

    if (isEnabled && savedToken && expiresAt > Date.now()) {
      cachedAccessToken = savedToken;
      if (savedUserJson) {
        currentDriveUser = JSON.parse(savedUserJson);
      } else {
        currentDriveUser = { email: 'حساب Google متصل' };
      }
      notifyStatus('idle');
    } else if (isEnabled && savedUserJson) {
      // User enabled sync previously, token may need refresh on next action
      currentDriveUser = JSON.parse(savedUserJson);
      notifyStatus('idle');
    } else {
      cachedAccessToken = null;
      currentDriveUser = null;
      notifyStatus('disabled');
    }
  } catch {
    cachedAccessToken = null;
    currentDriveUser = null;
    notifyStatus('disabled');
  }

  if (onUserChanged) onUserChanged(currentDriveUser);
  return () => {};
}

/**
 * Get active access token, with validity checking
 */
function getActiveToken(): string | null {
  if (cachedAccessToken) {
    const expiresAt = Number(localStorage.getItem('gdrive_token_expires_at') || '0');
    if (expiresAt === 0 || expiresAt > Date.now()) {
      return cachedAccessToken;
    }
  }
  const token = localStorage.getItem('gdrive_access_token');
  const expiresAt = Number(localStorage.getItem('gdrive_token_expires_at') || '0');
  if (token && (expiresAt === 0 || expiresAt > Date.now())) {
    cachedAccessToken = token;
    return token;
  }
  return null;
}

/**
 * Direct Google OAuth 2.0 Sign-In via Google Identity Services (No Firebase)
 */
export async function signInGoogleDrive(): Promise<{ user: DriveUserInfo; accessToken: string } | null> {
  await loadGsiScript();

  return new Promise((resolve, reject) => {
    try {
      const google = (window as any).google;
      if (!google?.accounts?.oauth2) {
        notifyStatus('error');
        return reject(new Error('تعذر تحميل خدمة Google Identity. يرجى التحقق من اتصال الإنترنت والمحاولة ثانية.'));
      }

      notifyStatus('syncing');

      const tokenClient = google.accounts.oauth2.initTokenClient({
        client_id: GOOGLE_CLIENT_ID,
        scope: DRIVE_SCOPES,
        prompt: '',
        callback: async (response: any) => {
          if (response.error) {
            console.warn('[GoogleDriveSync] OAuth Response error:', response.error);
            notifyStatus('error');
            return reject(new Error(`خطأ من Google: ${response.error}`));
          }

          if (response.access_token) {
            const token = response.access_token;
            cachedAccessToken = token;
            const expiresIn = Number(response.expires_in || 3599);
            const expiresAt = Date.now() + expiresIn * 1000;

            localStorage.setItem('gdrive_access_token', token);
            localStorage.setItem('gdrive_token_expires_at', String(expiresAt));
            localStorage.setItem('gdrive_sync_enabled', 'true');

            // Fetch user info directly from Google API
            let userObj: DriveUserInfo = { email: 'حساب Google متصل' };
            try {
              const userInfoRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                headers: { Authorization: `Bearer ${token}` },
              });
              if (userInfoRes.ok) {
                const info = await userInfoRes.json();
                userObj = {
                  email: info.email || 'حساب Google متصل',
                  name: info.name,
                  picture: info.picture,
                };
              }
            } catch (uErr) {
              console.warn('[GoogleDriveSync] Error fetching user profile:', uErr);
            }

            currentDriveUser = userObj;
            localStorage.setItem('gdrive_user_info', JSON.stringify(userObj));
            notifyStatus('idle');

            resolve({ user: userObj, accessToken: token });
          } else {
            notifyStatus('disabled');
            resolve(null);
          }
        },
        error_callback: (err: any) => {
          console.error('[GoogleDriveSync] Token client error:', err);
          notifyStatus('error');
          reject(new Error(err?.message || 'تعذر استكمال تسجيل الدخول'));
        },
      });

      tokenClient.requestAccessToken();
    } catch (err: any) {
      console.error('[GoogleDriveSync] Sign in error:', err);
      notifyStatus('error');
      reject(err);
    }
  });
}

/**
 * Disconnect Google Drive
 */
export async function signOutGoogleDrive() {
  try {
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }

    const token = cachedAccessToken || localStorage.getItem('gdrive_access_token');
    if (token && (window as any).google?.accounts?.oauth2?.revoke) {
      try {
        (window as any).google.accounts.oauth2.revoke(token, () => {});
      } catch {}
    }

    cachedAccessToken = null;
    currentDriveUser = null;
    localStorage.removeItem('gdrive_sync_enabled');
    localStorage.removeItem('gdrive_access_token');
    localStorage.removeItem('gdrive_token_expires_at');
    localStorage.removeItem('gdrive_user_info');
    notifyStatus('disabled');
  } catch (err) {
    console.error('[GoogleDriveSync] Sign out error:', err);
    localStorage.removeItem('gdrive_sync_enabled');
    localStorage.removeItem('gdrive_access_token');
    localStorage.removeItem('gdrive_token_expires_at');
    localStorage.removeItem('gdrive_user_info');
    notifyStatus('disabled');
  }
}

/**
 * Find existing backup file in Google Drive AppData
 */
async function findBackupFileInDrive(token: string): Promise<{ id: string; name: string } | null> {
  try {
    const q = encodeURIComponent(`name = '${BACKUP_FILENAME}' and trashed = false`);
    const url = `https://www.googleapis.com/drive/v3/files?q=${q}&spaces=appDataFolder,drive&fields=files(id,name,modifiedTime)`;

    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) return null;
    const data = await res.json();
    if (data.files && data.files.length > 0) {
      return data.files[0];
    }
    return null;
  } catch (err) {
    console.warn('[GoogleDriveSync] findBackupFile error:', err);
    return null;
  }
}

/**
 * Download backup JSON from Google Drive
 */
async function downloadBackupFromDrive(token: string, fileId: string): Promise<any | null> {
  try {
    const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.warn('[GoogleDriveSync] downloadBackup error:', err);
    return null;
  }
}

/**
 * Create or update backup JSON in Google Drive
 */
async function uploadBackupToDrive(token: string, fileData: any, existingFileId?: string | null): Promise<string | null> {
  try {
    const metadata = {
      name: BACKUP_FILENAME,
      mimeType: 'application/json',
      parents: existingFileId ? undefined : ['appDataFolder'],
    };

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      'Content-Type: application/json\r\n\r\n' +
      JSON.stringify(fileData) +
      closeDelimiter;

    let url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
    let method = 'POST';

    if (existingFileId) {
      url = `https://www.googleapis.com/upload/drive/v3/files/${existingFileId}?uploadType=multipart`;
      method = 'PATCH';
    }

    const res = await fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartRequestBody,
    });

    if (!res.ok) {
      console.warn('[GoogleDriveSync] Upload failed status:', res.status);
      return null;
    }

    const json = await res.json();
    return json.id || existingFileId || null;
  } catch (err) {
    console.error('[GoogleDriveSync] uploadBackup error:', err);
    return null;
  }
}

// ----------------------------------------------------
// CRDT / Deterministic Event Sourcing Ledger Merger
// ----------------------------------------------------

export interface LedgerSyncPayload {
  version: number;
  lastUpdated: string;
  deviceId: string;
  userId: number;
  debtors: Debtor[];
  installments: InstallmentRecord[];
  suppliers: Supplier[];
}

/**
 * Deterministically merges local and remote ledger data.
 * Solves offline concurrent transactions from multiple devices on the same debtor/installment/supplier!
 */
export function mergeLedgerData(
  local: { debtors: Debtor[]; installments: InstallmentRecord[]; suppliers: Supplier[] },
  remote: { debtors: Debtor[]; installments: InstallmentRecord[]; suppliers: Supplier[] }
): { mergedDebtors: Debtor[]; mergedInstallments: InstallmentRecord[]; mergedSuppliers: Supplier[] } {

  // 1. Merge Debtors
  const debtorMap = new Map<number, { local?: Debtor; remote?: Debtor }>();
  (local.debtors || []).forEach((d) => debtorMap.set(d.id, { ...debtorMap.get(d.id), local: d }));
  (remote.debtors || []).forEach((d) => debtorMap.set(d.id, { ...debtorMap.get(d.id), remote: d }));

  const mergedDebtors: Debtor[] = [];

  debtorMap.forEach(({ local: l, remote: r }, id) => {
    if (l && !r) {
      mergedDebtors.push(l);
      return;
    }
    if (!l && r) {
      mergedDebtors.push(r);
      return;
    }
    if (l && r) {
      const txMap = new Map<string, DebtorTransaction>();
      (l.history || []).forEach((tx) => {
        const key = tx.id || `tx_${tx.type}_${tx.date}_${tx.amount}`;
        txMap.set(key, tx);
      });
      (r.history || []).forEach((tx) => {
        const key = tx.id || `tx_${tx.type}_${tx.date}_${tx.amount}`;
        if (!txMap.has(key)) {
          txMap.set(key, tx);
        }
      });

      const mergedHistory = Array.from(txMap.values()).sort((a, b) => {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      });

      let computedAmount = 0;
      mergedHistory.forEach((tx) => {
        if (tx.type === 'initial' || tx.type === 'add') {
          computedAmount += Number(tx.amount || 0);
        } else if (tx.type === 'pay') {
          computedAmount -= Number(tx.amount || 0);
        }
      });
      if (computedAmount < 0) computedAmount = 0;

      mergedDebtors.push({
        id,
        name: l.name || r.name,
        phone: l.phone || r.phone,
        amount: computedAmount,
        status: computedAmount <= 0 ? 'مسدد' : 'مستمر',
        userId: l.userId || r.userId,
        createdAt: l.createdAt || r.createdAt,
        lastDebtDate: l.lastDebtDate || r.lastDebtDate,
        notes: l.notes || r.notes,
        history: mergedHistory,
        type: l.type || r.type || 'debtor',
      });
    }
  });

  // 2. Merge Installments
  const instMap = new Map<number, { local?: InstallmentRecord; remote?: InstallmentRecord }>();
  (local.installments || []).forEach((inst) => instMap.set(inst.id, { ...instMap.get(inst.id), local: inst }));
  (remote.installments || []).forEach((inst) => instMap.set(inst.id, { ...instMap.get(inst.id), remote: inst }));

  const mergedInstallments: InstallmentRecord[] = [];

  instMap.forEach(({ local: l, remote: r }, id) => {
    if (l && !r) {
      mergedInstallments.push(l);
      return;
    }
    if (!l && r) {
      mergedInstallments.push(r);
      return;
    }
    if (l && r) {
      const payMap = new Map<string, InstallmentPayment>();
      (l.payments || []).forEach((p) => {
        const key = p.id || `pay_${p.date}_${p.amount}`;
        payMap.set(key, p);
      });
      (r.payments || []).forEach((p) => {
        const key = p.id || `pay_${p.date}_${p.amount}`;
        if (!payMap.has(key)) {
          payMap.set(key, p);
        }
      });

      const mergedPayments = Array.from(payMap.values()).sort((a, b) => {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      });

      const totalAmount = Number(l.totalAmount || r.totalAmount || 0);
      const downPayment = Number(l.downPayment || r.downPayment || 0);
      const totalPaid = mergedPayments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
      const remainingAmount = Math.max(0, totalAmount - downPayment - totalPaid);

      mergedInstallments.push({
        id,
        name: l.name || r.name,
        phone: l.phone || r.phone,
        item: l.item || r.item,
        totalAmount,
        downPayment,
        remainingAmount,
        monthlyInstallmentAmount: l.monthlyInstallmentAmount || r.monthlyInstallmentAmount,
        registrationDate: l.registrationDate || r.registrationDate,
        nextDueDate: l.nextDueDate || r.nextDueDate,
        userId: l.userId || r.userId,
        status: remainingAmount <= 0 ? 'completed' : l.status || r.status,
        notes: l.notes || r.notes,
        payments: mergedPayments,
        createdAt: l.createdAt || r.createdAt,
      });
    }
  });

  // 3. Merge Suppliers
  const suppMap = new Map<number, { local?: Supplier; remote?: Supplier }>();
  (local.suppliers || []).forEach((s) => suppMap.set(s.id, { ...suppMap.get(s.id), local: s }));
  (remote.suppliers || []).forEach((s) => suppMap.set(s.id, { ...suppMap.get(s.id), remote: s }));

  const mergedSuppliers: Supplier[] = [];

  suppMap.forEach(({ local: l, remote: r }, id) => {
    if (l && !r) {
      mergedSuppliers.push(l);
      return;
    }
    if (!l && r) {
      mergedSuppliers.push(r);
      return;
    }
    if (l && r) {
      const txMap = new Map<string, SupplierTransaction>();
      (l.history || []).forEach((tx) => {
        const key = tx.id || `supp_tx_${tx.type}_${tx.date}_${tx.amount}`;
        txMap.set(key, tx);
      });
      (r.history || []).forEach((tx) => {
        const key = tx.id || `supp_tx_${tx.type}_${tx.date}_${tx.amount}`;
        if (!txMap.has(key)) {
          txMap.set(key, tx);
        }
      });

      const mergedHistory = Array.from(txMap.values()).sort((a, b) => {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      });

      let computedAmount = 0;
      mergedHistory.forEach((tx) => {
        if (tx.type === 'debt' || tx.type === 'initial' || tx.type === 'add_debt') {
          computedAmount += Number(tx.amount || 0);
        } else if (tx.type === 'pay' || tx.type === 'pay_supplier') {
          computedAmount -= Number(tx.amount || 0);
        }
      });
      if (computedAmount < 0) computedAmount = 0;

      mergedSuppliers.push({
        id,
        name: l.name || r.name,
        companyName: l.companyName || r.companyName,
        phone: l.phone || r.phone,
        notes: l.notes || r.notes,
        amount: computedAmount,
        createdAt: l.createdAt || r.createdAt,
        updatedAt: l.updatedAt || r.updatedAt,
        history: mergedHistory,
        userId: l.userId || r.userId,
        itemType: l.itemType || r.itemType,
        status: l.status || r.status,
        lastTransactionDate: l.lastTransactionDate || r.lastTransactionDate,
      });
    }
  });

  return { mergedDebtors, mergedInstallments, mergedSuppliers };
}

/**
 * Trigger background debounced Google Drive auto-sync.
 * Merges local and remote states without data loss.
 */
export function triggerGoogleDriveAutoSync(
  userId: number,
  localData: { debtors: Debtor[]; installments: InstallmentRecord[]; suppliers: Supplier[] },
  onDataMerged?: (merged: { debtors: Debtor[]; installments: InstallmentRecord[]; suppliers: Supplier[] }) => void
) {
  const isEnabled = localStorage.getItem('gdrive_sync_enabled') === 'true';
  if (!isEnabled) return;

  if (debounceTimer) clearTimeout(debounceTimer);

  debounceTimer = setTimeout(async () => {
    if (isSyncing) return;
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      notifyStatus('offline_queued');
      return;
    }

    const token = getActiveToken();
    if (!token) {
      notifyStatus(currentDriveUser ? 'idle' : 'disabled');
      return;
    }

    isSyncing = true;
    notifyStatus('syncing');

    try {
      // 1. Check if backup file exists in Drive
      const fileInfo = await findBackupFileInDrive(token);
      const fileId = fileInfo?.id || null;

      let remoteData: { debtors: Debtor[]; installments: InstallmentRecord[]; suppliers: Supplier[] } = {
        debtors: [],
        installments: [],
        suppliers: [],
      };

      if (fileId) {
        const downloaded = await downloadBackupFromDrive(token, fileId);
        if (downloaded) {
          remoteData = {
            debtors: downloaded.debtors || [],
            installments: downloaded.installments || [],
            suppliers: downloaded.suppliers || [],
          };
        }
      }

      // 2. CRDT Event-sourcing Merge
      const { mergedDebtors, mergedInstallments, mergedSuppliers } = mergeLedgerData(localData, remoteData);

      // 3. Save merged data locally if remote had new data
      await saveIdbDebtors(userId, mergedDebtors);
      setLocalDebtors(userId, mergedDebtors);

      await saveIdbInstallments(userId, mergedInstallments);
      setLocalInstallments(userId, mergedInstallments);

      await saveIdbSuppliers(userId, mergedSuppliers);
      setLocalSuppliers(userId, mergedSuppliers);

      if (onDataMerged) {
        onDataMerged({
          debtors: mergedDebtors,
          installments: mergedInstallments,
          suppliers: mergedSuppliers,
        });
      }

      // 4. Upload merged state back to Drive
      const payload: LedgerSyncPayload = {
        version: 2,
        lastUpdated: new Date().toISOString(),
        deviceId: `dev_${Math.random().toString(36).substring(2, 9)}`,
        userId,
        debtors: mergedDebtors,
        installments: mergedInstallments,
        suppliers: mergedSuppliers,
      };

      const newFileId = await uploadBackupToDrive(token, payload, fileId);
      if (newFileId) {
        lastSyncedAt = new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' });
        notifyStatus('synced');
      } else {
        notifyStatus('idle');
      }
    } catch (err) {
      console.error('[GoogleDriveSync] Auto sync error:', err);
      notifyStatus('error');
    } finally {
      isSyncing = false;
    }
  }, 1500);
}

// Online reconnection listener
if (typeof window !== 'undefined') {
  window.addEventListener('online', () => {
    if (localStorage.getItem('gdrive_sync_enabled') === 'true') {
      const session = JSON.parse(localStorage.getItem('user_session') || '{}');
      if (session && session.id) {
        const localDebtors = getLocalDebtors(session.id) || [];
        const localInstallments = getLocalInstallments(session.id) || [];
        const localSuppliers = getLocalSuppliers(session.id) || [];
        triggerGoogleDriveAutoSync(session.id, {
          debtors: localDebtors,
          installments: localInstallments,
          suppliers: localSuppliers,
        });
      }
    }
  });
}
