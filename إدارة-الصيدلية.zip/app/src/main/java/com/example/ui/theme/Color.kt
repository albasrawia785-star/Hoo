package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Theme Palette (Material 3 style)
val SleekPrimary = Color(0xFF0061A4)
val SleekOnPrimary = Color(0xFFFFFFFF)
val SleekPrimaryContainer = Color(0xFFD1E4FF)
val SleekOnPrimaryContainer = Color(0xFF001D36)

val SleekBackground = Color(0xFFF8F9FF)
val SleekOnBackground = Color(0xFF1A1C1E)

val SleekSurface = Color(0xFFFFFFFF)
val SleekOnSurface = Color(0xFF1A1C1E)
val SleekSurfaceVariant = Color(0xFFF3F4F9)
val SleekOnSurfaceVariant = Color(0xFF44474E)

val SleekErrorContainer = Color(0xFFFFDAD6)
val SleekOnErrorContainer = Color(0xFF410002)

val SleekOutline = Color(0xFFC3C6CF)
val SleekDivider = Color(0xFFE1E2EC)

val SleekSecondary = Color(0xFF00A8CC)
val SleekSecondaryContainer = Color(0xFFDEE3EB)
val SleekOnSecondaryContainer = Color(0xFF44474E)

