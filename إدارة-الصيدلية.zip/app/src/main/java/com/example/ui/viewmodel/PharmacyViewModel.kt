package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.exporter.ReportExporter
import com.example.data.local.database.AppDatabase
import com.example.data.local.entities.Company
import com.example.data.local.entities.Invoice
import com.example.data.local.entities.InvoiceItem
import com.example.data.local.entities.Medicine
import com.example.data.printer.BluetoothPrinterHelper
import com.example.data.repository.PharmacyRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class PharmacyViewModel(
    application: Application,
    private val repository: PharmacyRepository
) : AndroidViewModel(application) {

    private val context = application.applicationContext

    // --- State Streams ---
    val allMedicines: StateFlow<List<Medicine>> = repository.allMedicines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCompanies: StateFlow<List<Company>> = repository.allCompanies
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allInvoices: StateFlow<List<Invoice>> = repository.allInvoices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockMedicines: StateFlow<List<Medicine>> = repository.lowStockMedicines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expiringSoonMedicines: StateFlow<List<Medicine>> = repository.getExpiringSoonMedicines(System.currentTimeMillis())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- POS Cart State ---
    data class CartItem(
        val medicine: Medicine,
        val quantity: Int
    ) {
        val subtotal: Double get() = medicine.salePrice * quantity
    }

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _discount = MutableStateFlow(0.0) // Fixed IQD discount
    val discount: StateFlow<Double> = _discount.asStateFlow()

    private val _taxPercent = MutableStateFlow(0.0) // Tax percentage
    val taxPercent: StateFlow<Double> = _taxPercent.asStateFlow()

    private val _paidAmount = MutableStateFlow(0.0)
    val paidAmount: StateFlow<Double> = _paidAmount.asStateFlow()

    // --- POS Search State ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchResults: StateFlow<List<Medicine>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) {
                repository.allMedicines
            } else {
                repository.searchMedicines(query)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Bluetooth Printer States ---
    private val _pairedPrinters = MutableStateFlow<List<BluetoothPrinterHelper.PrinterDevice>>(emptyList())
    val pairedPrinters: StateFlow<List<BluetoothPrinterHelper.PrinterDevice>> = _pairedPrinters.asStateFlow()

    private val _selectedPrinterMac = MutableStateFlow<String?>(null)
    val selectedPrinterMac: StateFlow<String?> = _selectedPrinterMac.asStateFlow()

    private val _isPrinting = MutableStateFlow(false)
    val isPrinting: StateFlow<Boolean> = _isPrinting.asStateFlow()

    init {
        loadPrinters()
        _selectedPrinterMac.value = BluetoothPrinterHelper.getDefaultPrinterMac(context)
    }

    // --- Cart Actions ---
    fun addToCart(medicine: Medicine) {
        if (medicine.stockQuantity <= 0) return // No stock left
        
        val currentList = _cart.value.toMutableList()
        val existingIndex = currentList.indexOfFirst { it.medicine.id == medicine.id }

        if (existingIndex != -1) {
            val existingItem = currentList[existingIndex]
            if (existingItem.quantity < medicine.stockQuantity) {
                currentList[existingIndex] = existingItem.copy(quantity = existingItem.quantity + 1)
            }
        } else {
            currentList.add(CartItem(medicine = medicine, quantity = 1))
        }
        _cart.value = currentList
    }

    fun removeFromCart(medicine: Medicine) {
        val currentList = _cart.value.filter { it.medicine.id != medicine.id }
        _cart.value = currentList
    }

    fun updateCartQuantity(medicine: Medicine, qty: Int) {
        if (qty <= 0) {
            removeFromCart(medicine)
            return
        }
        if (qty > medicine.stockQuantity) return // Exceeds stock
        
        val currentList = _cart.value.toMutableList()
        val index = currentList.indexOfFirst { it.medicine.id == medicine.id }
        if (index != -1) {
            currentList[index] = currentList[index].copy(quantity = qty)
            _cart.value = currentList
        }
    }

    fun setDiscount(value: Double) {
        _discount.value = value.coerceAtLeast(0.0)
    }

    fun setTaxPercent(value: Double) {
        _taxPercent.value = value.coerceIn(0.0, 100.0)
    }

    fun setPaidAmount(value: Double) {
        _paidAmount.value = value.coerceAtLeast(0.0)
    }

    fun clearCart() {
        _cart.value = emptyList()
        _discount.value = 0.0
        _taxPercent.value = 0.0
        _paidAmount.value = 0.0
    }

    // --- Checkout Logic ---
    suspend fun checkout(): Long? {
        val items = _cart.value
        if (items.isEmpty()) return null

        val subtotal = items.sumOf { it.subtotal }
        val tax = subtotal * (_taxPercent.value / 100.0)
        val finalAmount = (subtotal + tax - _discount.value).coerceAtLeast(0.0)
        val change = (_paidAmount.value - finalAmount).coerceAtLeast(0.0)

        val invoiceNumber = "INV-${System.currentTimeMillis() / 1000}"
        
        val invoice = Invoice(
            invoiceNumber = invoiceNumber,
            totalAmount = subtotal,
            discountAmount = _discount.value,
            taxAmount = tax,
            finalAmount = finalAmount,
            paidAmount = _paidAmount.value,
            changeAmount = change
        )

        val invoiceItems = items.map { cartItem ->
            InvoiceItem(
                invoiceId = 0, // Assigned by Room Transaction
                medicineId = cartItem.medicine.id,
                medicineName = cartItem.medicine.tradeName,
                quantity = cartItem.quantity,
                unitPrice = cartItem.medicine.salePrice,
                subtotal = cartItem.subtotal
            )
        }

        return try {
            val invoiceId = repository.createInvoiceWithItems(invoice, invoiceItems)
            clearCart()
            invoiceId
        } catch (e: Exception) {
            Log.e("PharmacyViewModel", "Checkout failed", e)
            null
        }
    }

    // --- Inventory Actions ---
    fun saveMedicine(medicine: Medicine) {
        viewModelScope.launch {
            if (medicine.id == 0L) {
                repository.insertMedicine(medicine)
            } else {
                repository.updateMedicine(medicine)
            }
        }
    }

    fun deleteMedicine(medicine: Medicine) {
        viewModelScope.launch {
            repository.deleteMedicine(medicine)
        }
    }

    fun addStock(medicineId: Long, amount: Int) {
        viewModelScope.launch {
            repository.addStock(medicineId, amount)
        }
    }

    // --- Company Actions ---
    fun saveCompany(company: Company) {
        viewModelScope.launch {
            if (company.id == 0L) {
                repository.insertCompany(company)
            } else {
                repository.updateCompany(company)
            }
        }
    }

    fun deleteCompany(company: Company) {
        viewModelScope.launch {
            repository.deleteCompany(company)
        }
    }

    // --- Search query update ---
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // --- Bluetooth Printer Operations ---
    fun loadPrinters() {
        _pairedPrinters.value = BluetoothPrinterHelper.getPairedPrinters(context)
    }

    fun selectPrinter(macAddress: String) {
        _selectedPrinterMac.value = macAddress
        BluetoothPrinterHelper.saveDefaultPrinterMac(context, macAddress)
    }

    fun printReceipt(invoiceId: Long, onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            _isPrinting.value = true
            val invoice = repository.getInvoiceById(invoiceId)
            if (invoice != null) {
                // Get items synchronously
                val items = repository.getInvoiceItemsForInvoiceSync(invoiceId)
                val success = BluetoothPrinterHelper.printInvoice(
                    context = context,
                    invoice = invoice,
                    items = items,
                    printerMac = _selectedPrinterMac.value
                )
                onResult(success)
            } else {
                onResult(false)
            }
            _isPrinting.value = false
        }
    }

    suspend fun getInvoiceItemsForInvoiceSync(invoiceId: Long): List<InvoiceItem> {
        return repository.getInvoiceItemsForInvoiceSync(invoiceId)
    }

    // --- Export Operations ---
    fun exportInventoryPdf(onComplete: (File?) -> Unit) {
        viewModelScope.launch(Dispatchers.Default) {
            val medicines = allMedicines.value
            val file = ReportExporter.exportInventoryToPdf(context, medicines)
            withContext(Dispatchers.Main) {
                onComplete(file)
            }
        }
    }

    fun exportSalesCsv(onComplete: (File?) -> Unit) {
        viewModelScope.launch(Dispatchers.Default) {
            val invoices = allInvoices.value
            val file = ReportExporter.exportInvoicesToCsv(context, invoices)
            withContext(Dispatchers.Main) {
                onComplete(file)
            }
        }
    }
}

class PharmacyViewModelFactory(
    private val application: Application,
    private val repository: PharmacyRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PharmacyViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PharmacyViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
