package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import com.example.data.backup.DatabaseBackupHelper
import com.example.data.local.entities.Company
import com.example.data.local.entities.Invoice
import com.example.data.local.entities.InvoiceItem
import com.example.data.local.entities.Medicine
import com.example.ui.viewmodel.PharmacyViewModel
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Navigation Tabs
enum class PharmacyTab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    DASHBOARD("لوحة التحكم", Icons.Default.Dashboard),
    POS("نقطة البيع", Icons.Default.ShoppingCart),
    INVENTORY("المخزن", Icons.Default.Inventory),
    COMPANIES("الشركات الموردة", Icons.Default.Business),
    REPORTS("التقارير والنسخ", Icons.Default.Assessment)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PharmacyApp(viewModel: PharmacyViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var currentTab by remember { mutableStateOf(PharmacyTab.DASHBOARD) }
    var showPrinterDialog by remember { mutableStateOf(false) }

    // Enforce RTL Layout Direction globally for Arabic Language Support
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalPharmacy,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Text(
                                text = "صيدلية الشفاء الذكية",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showPrinterDialog = true },
                            modifier = Modifier.testTag("printer_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Print,
                                contentDescription = "إعدادات الطابعة",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                ) {
                    PharmacyTab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = currentTab == tab,
                            onClick = { currentTab = tab },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label, fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                when (currentTab) {
                    PharmacyTab.DASHBOARD -> DashboardScreen(viewModel, onNavigateToTab = { currentTab = it })
                    PharmacyTab.POS -> POSScreen(viewModel)
                    PharmacyTab.INVENTORY -> InventoryScreen(viewModel)
                    PharmacyTab.COMPANIES -> CompaniesScreen(viewModel)
                    PharmacyTab.REPORTS -> ReportsScreen(viewModel)
                }

                if (showPrinterDialog) {
                    PrinterConfigDialog(
                        viewModel = viewModel,
                        onDismiss = { showPrinterDialog = false }
                    )
                }
            }
        }
    }
}

// --- SCREEN 1: DASHBOARD ---
@Composable
fun DashboardScreen(
    viewModel: PharmacyViewModel,
    onNavigateToTab: (PharmacyTab) -> Unit
) {
    val medicines by viewModel.allMedicines.collectAsState()
    val lowStock by viewModel.lowStockMedicines.collectAsState()
    val expiringSoon by viewModel.expiringSoonMedicines.collectAsState()
    val invoices by viewModel.allInvoices.collectAsState()

    // Calculate today's sales
    val todaySales = remember(invoices) {
        val todayStart = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date())
        invoices.filter {
            val invoiceDate = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(it.timestamp))
            invoiceDate == todayStart
        }.sumOf { it.finalAmount }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "مرحباً بك في نظام إدارة الصيدلية",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "النظام يعمل بالكامل دون اتصال بالإنترنت (Offline-first) مع أتمتة جرد المخزن وطباعة البلوتوث.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // Stats Grid in a Flow or Column
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KpiCard(
                        title = "مبيعات اليوم",
                        value = formatIqd(todaySales),
                        icon = Icons.Default.MonetizationOn,
                        color = Color(0xFF2E7D32),
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        subtitle = "د.ع • ${invoices.size} فاتورة",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(PharmacyTab.REPORTS) }
                    )
                    KpiCard(
                        title = "إجمالي المواد",
                        value = medicines.size.toString(),
                        icon = Icons.Default.Category,
                        color = MaterialTheme.colorScheme.primary,
                        subtitle = "مادة نشطة بالمخزن",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(PharmacyTab.INVENTORY) }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KpiCard(
                        title = "مواد قاربت على النفاد",
                        value = lowStock.size.toString(),
                        icon = Icons.Default.Warning,
                        color = Color(0xFFE65100),
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer,
                        subtitle = "نواقص عاجلة",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(PharmacyTab.INVENTORY) }
                    )
                    KpiCard(
                        title = "قريب الانتهاء",
                        value = expiringSoon.size.toString(),
                        icon = Icons.Default.EventBusy,
                        color = Color(0xFFC62828),
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer,
                        subtitle = "تنبيهات الصلاحية",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(PharmacyTab.INVENTORY) }
                    )
                }
            }
        }

        // Alerts Header
        if (lowStock.isNotEmpty() || expiringSoon.isNotEmpty()) {
            item {
                Text(
                    text = "تنبيهات المخزن العاجلة",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }

        // Low stock alerts list
        if (lowStock.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 8.dp)
                        ) {
                            Icon(Icons.Default.TrendingDown, contentDescription = null, tint = Color(0xFFE65100))
                            Text("أوشكت كميتها على النفاد (${lowStock.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        lowStock.take(3).forEach { med ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(med.tradeName, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text("الكمية المتبقية: ${med.stockQuantity}", color = Color(0xFFC62828), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (lowStock.size > 3) {
                            Text(
                                "وعرض بقية النواقص في صفحة المخزن...",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clickable { onNavigateToTab(PharmacyTab.INVENTORY) }
                                    .padding(top = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Expiry alerts list
        if (expiringSoon.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 8.dp)
                        ) {
                            Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = Color(0xFFC62828))
                            Text("أدوية قاربت صلاحيتها على الانتهاء (${expiringSoon.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        expiringSoon.take(3).forEach { med ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(med.tradeName, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text("تنتهي في: ${med.expiryDate}", color = Color(0xFFE65100), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (expiringSoon.size > 3) {
                            Text(
                                "وعرض بقية الأدوية المنتهية في صفحة المخزن...",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clickable { onNavigateToTab(PharmacyTab.INVENTORY) }
                                    .padding(top = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KpiCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    containerColor: Color? = null,
    contentColor: Color? = null,
    subtitle: String? = null,
    onClick: () -> Unit
) {
    val finalContainerColor = containerColor ?: MaterialTheme.colorScheme.surface
    val finalContentColor = contentColor ?: MaterialTheme.colorScheme.onSurface
    val finalTitleColor = contentColor?.copy(alpha = 0.8f) ?: MaterialTheme.colorScheme.onSurfaceVariant

    Card(
        onClick = onClick,
        modifier = modifier.height(115.dp),
        shape = RoundedCornerShape(24.dp), // Sleek 3xl rounded corners (24dp)
        colors = CardDefaults.cardColors(containerColor = finalContainerColor),
        border = if (containerColor == null) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)) else null
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title, 
                    fontSize = 11.sp, 
                    color = finalTitleColor, 
                    fontWeight = FontWeight.SemiBold
                )
                if (containerColor == null) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .background(color.copy(alpha = 0.12f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
                    }
                }
            }
            Column {
                Text(
                    text = value,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = finalContentColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        fontSize = 9.sp,
                        color = finalTitleColor.copy(alpha = 0.75f),
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

// --- SCREEN 2: POINT OF SALE (POS) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun POSScreen(viewModel: PharmacyViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val cart by viewModel.cart.collectAsState()
    
    val discount by viewModel.discount.collectAsState()
    val taxPercent by viewModel.taxPercent.collectAsState()
    val paidAmount by viewModel.paidAmount.collectAsState()

    var showScanner by remember { mutableStateOf(false) }
    var showCheckoutDialog by remember { mutableStateOf(false) }
    var activeInvoiceIdForReceipt by remember { mutableStateOf<Long?>(null) }

    // Computations
    val subtotal = remember(cart) { cart.sumOf { it.subtotal } }
    val tax = remember(subtotal, taxPercent) { subtotal * (taxPercent / 100.0) }
    val finalAmount = remember(subtotal, tax, discount) { (subtotal + tax - discount).coerceAtLeast(0.0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        // Upper search and scanning block
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                label = { Text("بحث باسم الدواء أو الباركود") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("pos_search_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
            FilledIconButton(
                onClick = { showScanner = true },
                modifier = Modifier
                    .size(56.dp)
                    .testTag("pos_scan_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = "قراءة الباركود بالكاميرا")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Split Layout: Upper/Left for Cart, Lower/Right for Search Results
        Row(modifier = Modifier.weight(1f)) {
            // Cart Column (Occupies 55% space)
            Column(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight()
                    .padding(end = 4.dp)
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("سلة البيع (${cart.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    if (cart.isNotEmpty()) {
                        TextButton(onClick = { viewModel.clearCart() }) {
                            Text("تفريغ", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        }
                    }
                }

                if (cart.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(48.dp))
                            Text("السلة فارغة حالياً", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(cart) { item ->
                            CartRow(item, onQtyChange = { qty -> viewModel.updateCartQuantity(item.medicine, qty) })
                        }
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 4.dp))

                // Calculations
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text("الإجمالي الفرعي", fontSize = 12.sp, color = Color.Gray)
                        Text(formatIqd(subtotal), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Text("الخصم الممنوح (د.ع)", fontSize = 12.sp, color = Color.Gray)
                        OutlinedTextField(
                            value = if (discount == 0.0) "" else discount.toInt().toString(),
                            onValueChange = { viewModel.setDiscount(it.toDoubleOrNull() ?: 0.0) },
                            modifier = Modifier
                                .width(90.dp)
                                .height(40.dp)
                                .testTag("discount_input"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, textAlign = TextAlign.Center),
                            colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent)
                        )
                    }

                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text("المجموع النهائي", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(formatIqd(finalAmount), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { showCheckoutDialog = true },
                    enabled = cart.isNotEmpty(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("checkout_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("حفظ ودفع الفاتورة 💳", fontWeight = FontWeight.Bold)
                }
            }

            // Products Column (Occupies 45% space for fast choosing)
            Column(
                modifier = Modifier
                    .weight(0.9f)
                    .fillMaxHeight()
                    .padding(start = 4.dp)
            ) {
                Text(
                    text = "المواد المتاحة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 4.dp)
                )

                if (searchResults.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("لا يوجد مواد", color = Color.Gray, fontSize = 12.sp)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(searchResults) { med ->
                            ProductSelectionCard(med, onAdd = { viewModel.addToCart(med) })
                        }
                    }
                }
            }
        }
    }

    // --- Barcode Scanner Simulation Dialog ---
    if (showScanner) {
        BarcodeScannerSimDialog(
            viewModel = viewModel,
            onDismiss = { showScanner = false }
        )
    }

    // --- Checkout Pay Dialog ---
    if (showCheckoutDialog) {
        Dialog(onDismissRequest = { showCheckoutDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text("تأكيد دفع الفاتورة 💰", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text("المجموع النهائي الصافي:")
                        Text(formatIqd(finalAmount), fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary, fontSize = 16.sp)
                    }

                    OutlinedTextField(
                        value = if (paidAmount == 0.0) "" else paidAmount.toInt().toString(),
                        onValueChange = { viewModel.setPaidAmount(it.toDoubleOrNull() ?: 0.0) },
                        label = { Text("المبلغ المدفوع من العميل (د.ع)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("paid_amount_input"),
                        singleLine = true
                    )

                    val change = (paidAmount - finalAmount).coerceAtLeast(0.0)
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Text("المتبقي لإرجاعه للعميل:")
                        Text(formatIqd(change), fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32), fontSize = 16.sp)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showCheckoutDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء")
                        }
                        Button(
                            onClick = {
                                if (paidAmount < finalAmount) {
                                    Toast.makeText(context, "المبلغ المدفوع غير كافٍ!", Toast.LENGTH_SHORT).show()
                                } else {
                                    scope.launch {
                                        val id = viewModel.checkout()
                                        showCheckoutDialog = false
                                        if (id != null) {
                                            activeInvoiceIdForReceipt = id
                                        } else {
                                            Toast.makeText(context, "فشل حفظ الفاتورة!", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("confirm_payment_button")
                        ) {
                            Text("تأكيد وحفظ")
                        }
                    }
                }
            }
        }
    }

    // --- Print Invoice Receipt Flow Dialog ---
    if (activeInvoiceIdForReceipt != null) {
        Dialog(onDismissRequest = { activeInvoiceIdForReceipt = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(56.dp))
                    Text("تم حفظ الفاتورة بنجاح!", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("هل تريد طباعة الفاتورة الحرارية الآن عبر طابعة البلوتوث؟", textAlign = TextAlign.Center, fontSize = 13.sp)

                    Button(
                        onClick = {
                            val invId = activeInvoiceIdForReceipt
                            if (invId != null) {
                                viewModel.printReceipt(invId) { success ->
                                    if (success) {
                                        Toast.makeText(context, "تم إرسال أمر الطباعة!", Toast.LENGTH_SHORT).show()
                                        activeInvoiceIdForReceipt = null
                                    } else {
                                        Toast.makeText(context, "فشل الاتصال بالطابعة أو لم يتم إعدادها!", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("print_receipt_action"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Print, contentDescription = null)
                            Text("طباعة الفاتورة")
                        }
                    }

                    TextButton(onClick = { activeInvoiceIdForReceipt = null }) {
                        Text("تخطي وإغلاق")
                    }
                }
            }
        }
    }
}

@Composable
fun CartRow(item: PharmacyViewModel.CartItem, onQtyChange: (Int) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(item.medicine.tradeName, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(formatIqd(item.subtotal), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${formatIqd(item.medicine.salePrice)} مفرّد", fontSize = 10.sp, color = Color.Gray)
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = { onQtyChange(item.quantity - 1) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.RemoveCircleOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                    Text(item.quantity.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    IconButton(
                        onClick = { onQtyChange(item.quantity + 1) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.AddCircleOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ProductSelectionCard(medicine: Medicine, onAdd: () -> Unit) {
    val context = LocalContext.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                if (medicine.stockQuantity <= 0) {
                    Toast
                        .makeText(context, "المادة غير متوفرة بالمخزن!", Toast.LENGTH_SHORT)
                        .show()
                } else {
                    onAdd()
                }
            },
        colors = CardDefaults.cardColors(
            containerColor = if (medicine.stockQuantity <= 0) Color.LightGray.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(medicine.tradeName, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(medicine.scientificName, fontSize = 10.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(formatIqd(medicine.salePrice), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                
                if (medicine.stockQuantity <= 0) {
                    Text("نفد", color = Color.Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                } else {
                    Text("المخزون: ${medicine.stockQuantity}", fontSize = 10.sp, color = if (medicine.stockQuantity <= medicine.minStockLimit) Color.Red else Color.Gray)
                }
            }
        }
    }
}

// --- Barcode Scanner Simulation with Animation ---
@Composable
fun BarcodeScannerSimDialog(
    viewModel: PharmacyViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var simInput by remember { mutableStateOf("") }
    
    // Pulse scanning line animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val laserOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 180f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("قارئ الباركود الذكي للكاميرا", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                // Simulated Scanner Viewfinder
                Box(
                    modifier = Modifier
                        .size(220.dp, 180.dp)
                        .background(Color.Black, RoundedCornerShape(12.dp))
                        .clip(RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    // Draw Camera Preview placeholder or animated design
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.DarkGray, modifier = Modifier.size(36.dp))
                        Text("[ الكاميرا نشطة لقراءة الباركود ]", color = Color.DarkGray, fontSize = 11.sp)
                    }

                    // Red Laser Animation line
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawLine(
                            color = Color.Red,
                            start = Offset(10f, laserOffset),
                            end = Offset(size.width - 10f, laserOffset),
                            strokeWidth = 3f
                        )
                    }
                }

                Text(
                    "لمحاكاة قراءة باركود، اختر دواء من الأسفل أو اكتب باركود يدوياً:",
                    textAlign = TextAlign.Center,
                    fontSize = 11.sp,
                    color = Color.Gray
                )

                OutlinedTextField(
                    value = simInput,
                    onValueChange = { simInput = it },
                    label = { Text("أدخل رقم الباركود لمحاكاته") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("barcode_sim_input"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            if (simInput.isNotBlank()) {
                                scope.launch {
                                    val med = viewModel.allMedicines.value.firstOrNull { it.barcode == simInput }
                                    if (med != null) {
                                        viewModel.addToCart(med)
                                        Toast.makeText(context, "تمت إضافة: ${med.tradeName}", Toast.LENGTH_SHORT).show()
                                        onDismiss()
                                    } else {
                                        Toast.makeText(context, "لم يتم العثور على الدواء بهذا الباركود!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("قراءة الباركود")
                    }
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("إغلاق")
                    }
                }
                
                Divider()
                
                // Fast preset buttons for barcodes of seeded medicines
                Text("أكواد تجريبية سريعة للمحاكاة:", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Button(
                        onClick = { simInput = "5012345678901" },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(2.dp)
                    ) {
                        Text("بندول", fontSize = 10.sp)
                    }
                    Button(
                        onClick = { simInput = "6221122334455" },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(2.dp)
                    ) {
                        Text("أموكسي", fontSize = 10.sp)
                    }
                    Button(
                        onClick = { simInput = "5011122334455" },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(2.dp)
                    ) {
                        Text("بروفين", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

// --- SCREEN 3: INVENTORY (المخزن) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(viewModel: PharmacyViewModel) {
    val medicines by viewModel.searchResults.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val companies by viewModel.allCompanies.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedMedicineToEdit by remember { mutableStateOf<Medicine?>(null) }
    
    // Filters: 0 = All, 1 = Low Stock, 2 = Expiring soon
    var activeFilterTab by remember { mutableIntStateOf(0) }

    val filteredList = remember(medicines, activeFilterTab) {
        when (activeFilterTab) {
            1 -> medicines.filter { it.stockQuantity <= it.minStockLimit }
            2 -> {
                val threeMonthsInMs = 90 * 24 * 60 * 60 * 1000L
                medicines.filter { it.expiryTimestamp <= System.currentTimeMillis() + threeMonthsInMs }
            }
            else -> medicines
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_medicine_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة دواء")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                label = { Text("البحث في المخزن") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = activeFilterTab == 0,
                    onClick = { activeFilterTab = 0 },
                    label = { Text("الكل (${medicines.size})") }
                )
                FilterChip(
                    selected = activeFilterTab == 1,
                    onClick = { activeFilterTab = 1 },
                    label = { Text("النواقص") }
                )
                FilterChip(
                    selected = activeFilterTab == 2,
                    onClick = { activeFilterTab = 2 },
                    label = { Text("قريب الانتهاء") }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (filteredList.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لا توجد مواد تطابق هذا الفلتر", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredList) { med ->
                        val compName = companies.firstOrNull { it.id == med.companyId }?.name ?: "غير محدد"
                        MedicineInventoryCard(
                            medicine = med,
                            companyName = compName,
                            onEdit = { selectedMedicineToEdit = med }
                        )
                    }
                }
            }
        }
    }

    // Add Medicine Dialog
    if (showAddDialog) {
        MedicineFormDialog(
            companies = companies,
            onDismiss = { showAddDialog = false },
            onSave = { med ->
                viewModel.saveMedicine(med)
                showAddDialog = false
            }
        )
    }

    // Edit Medicine Dialog
    if (selectedMedicineToEdit != null) {
        MedicineFormDialog(
            medicine = selectedMedicineToEdit,
            companies = companies,
            onDismiss = { selectedMedicineToEdit = null },
            onSave = { med ->
                viewModel.saveMedicine(med)
                selectedMedicineToEdit = null
            },
            onDelete = { med ->
                viewModel.deleteMedicine(med)
                selectedMedicineToEdit = null
            }
        )
    }
}

@Composable
fun MedicineInventoryCard(
    medicine: Medicine,
    companyName: String,
    onEdit: () -> Unit
) {
    val isLowStock = medicine.stockQuantity <= medicine.minStockLimit
    val isExpiringSoon = (medicine.expiryTimestamp - System.currentTimeMillis()) < 90 * 24 * 60 * 60 * 1000L

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(medicine.tradeName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("الاسم العلمي: ${medicine.scientificName}", fontSize = 12.sp, color = Color.Gray)
                Text("الشركة الموردة: $companyName", fontSize = 12.sp, color = Color.Gray)
                
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("الشراء: ${formatIqd(medicine.purchasePrice)}", fontSize = 12.sp, color = Color.DarkGray)
                    Text("البيع: ${formatIqd(medicine.salePrice)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Event, contentDescription = null, tint = if (isExpiringSoon) Color(0xFFC62828) else Color.Gray, modifier = Modifier.size(14.dp))
                    Text("الصلاحية: ${medicine.expiryDate}", fontSize = 12.sp, color = if (isExpiringSoon) Color(0xFFC62828) else Color.Gray, fontWeight = if (isExpiringSoon) FontWeight.Bold else FontWeight.Normal)
                }
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            if (isLowStock) Color(0xFFFFEBEE) else Color(0xFFE8F5E9),
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "الكمية: ${medicine.stockQuantity}",
                        color = if (isLowStock) Color(0xFFC62828) else Color(0xFF2E7D32),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                
                if (isLowStock) {
                    Text("مخزون حرج", color = Color(0xFFC62828), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicineFormDialog(
    medicine: Medicine? = null,
    companies: List<Company>,
    onDismiss: () -> Unit,
    onSave: (Medicine) -> Unit,
    onDelete: ((Medicine) -> Unit)? = null
) {
    var tradeName by remember { mutableStateOf(medicine?.tradeName ?: "") }
    var scientificName by remember { mutableStateOf(medicine?.scientificName ?: "") }
    var barcode by remember { mutableStateOf(medicine?.barcode ?: "") }
    var purchasePrice by remember { mutableStateOf(medicine?.purchasePrice?.toInt()?.toString() ?: "") }
    var salePrice by remember { mutableStateOf(medicine?.salePrice?.toInt()?.toString() ?: "") }
    var stockQuantity by remember { mutableStateOf(medicine?.stockQuantity?.toString() ?: "") }
    var minStockLimit by remember { mutableStateOf(medicine?.minStockLimit?.toString() ?: "5") }
    var expiryDate by remember { mutableStateOf(medicine?.expiryDate ?: "") }
    var companyId by remember { mutableStateOf(medicine?.companyId) }

    var expandedCompanySelect by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        if (medicine == null) "إضافة دواء جديد للمخزن" else "تعديل تفاصيل الدواء",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                item {
                    OutlinedTextField(
                        value = tradeName,
                        onValueChange = { tradeName = it },
                        label = { Text("الاسم التجاري (مثال: بندول)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = scientificName,
                        onValueChange = { scientificName = it },
                        label = { Text("الاسم العلمي (مثال: Paracetamol)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = barcode,
                        onValueChange = { barcode = it },
                        label = { Text("رقم الباركود (اختياري)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = purchasePrice,
                            onValueChange = { purchasePrice = it },
                            label = { Text("سعر الشراء (د.ع)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = salePrice,
                            onValueChange = { salePrice = it },
                            label = { Text("سعر البيع (د.ع)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = stockQuantity,
                            onValueChange = { stockQuantity = it },
                            label = { Text("الكمية") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = minStockLimit,
                            onValueChange = { minStockLimit = it },
                            label = { Text("حد الطلب") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = expiryDate,
                        onValueChange = { expiryDate = it },
                        label = { Text("تاريخ الصلاحية (DD/MM/YYYY)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }

                // Company Supplier Select
                item {
                    val activeCompName = companies.firstOrNull { it.id == companyId }?.name ?: "اختر الشركة الموردة"
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { expandedCompanySelect = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(activeCompName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        }
                        DropdownMenu(
                            expanded = expandedCompanySelect,
                            onDismissRequest = { expandedCompanySelect = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            companies.forEach { comp ->
                                DropdownMenuItem(
                                    text = { Text(comp.name) },
                                    onClick = {
                                        companyId = comp.id
                                        expandedCompanySelect = false
                                    }
                                )
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (medicine != null && onDelete != null) {
                            Button(
                                onClick = { onDelete(medicine) },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                modifier = Modifier.weight(0.8f)
                            ) {
                                Text("حذف")
                            }
                        }
                        
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                            Text("إلغاء")
                        }
                        
                        Button(
                            onClick = {
                                if (tradeName.isBlank() || purchasePrice.toDoubleOrNull() == null || salePrice.toDoubleOrNull() == null || stockQuantity.toIntOrNull() == null) {
                                    // simple skip validation for simplicity, in production show toast
                                } else {
                                    // Parse or precalculate relative timestamp
                                    val timestamp = try {
                                        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.US)
                                        sdf.parse(expiryDate)?.time ?: System.currentTimeMillis()
                                    } catch (e: Exception) {
                                        System.currentTimeMillis() + 180 * 24 * 60 * 60 * 1000L // default 6 months
                                    }

                                    val savedMed = Medicine(
                                        id = medicine?.id ?: 0,
                                        tradeName = tradeName,
                                        scientificName = scientificName,
                                        barcode = barcode,
                                        purchasePrice = purchasePrice.toDouble(),
                                        salePrice = salePrice.toDouble(),
                                        stockQuantity = stockQuantity.toInt(),
                                        minStockLimit = minStockLimit.toIntOrNull() ?: 5,
                                        expiryDate = expiryDate,
                                        expiryTimestamp = timestamp,
                                        companyId = companyId
                                    )
                                    onSave(savedMed)
                                }
                            },
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("save_medicine_button")
                        ) {
                            Text("حفظ")
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 4: COMPANIES (الشركات الموردة) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompaniesScreen(viewModel: PharmacyViewModel) {
    val companies by viewModel.allCompanies.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedCompanyToEdit by remember { mutableStateOf<Company?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_company_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة شركة")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text("الشركات الموردة والمصانع", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(bottom = 12.dp))

            if (companies.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لا توجد شركات موردة مضافة", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(companies) { comp ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedCompanyToEdit = comp },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(comp.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                if (comp.phone.isNotBlank()) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                                        Text(comp.phone, fontSize = 12.sp, color = Color.DarkGray)
                                    }
                                }
                                if (comp.address.isNotBlank()) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                                        Text(comp.address, fontSize = 12.sp, color = Color.DarkGray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Company Dialog
    if (showAddDialog) {
        CompanyFormDialog(
            onDismiss = { showAddDialog = false },
            onSave = { comp ->
                viewModel.saveCompany(comp)
                showAddDialog = false
            }
        )
    }

    // Edit Company Dialog
    if (selectedCompanyToEdit != null) {
        CompanyFormDialog(
            company = selectedCompanyToEdit,
            onDismiss = { selectedCompanyToEdit = null },
            onSave = { comp ->
                viewModel.saveCompany(comp)
                selectedCompanyToEdit = null
            },
            onDelete = { comp ->
                viewModel.deleteCompany(comp)
                selectedCompanyToEdit = null
            }
        )
    }
}

@Composable
fun CompanyFormDialog(
    company: Company? = null,
    onDismiss: () -> Unit,
    onSave: (Company) -> Unit,
    onDelete: ((Company) -> Unit)? = null
) {
    var name by remember { mutableStateOf(company?.name ?: "") }
    var phone by remember { mutableStateOf(company?.phone ?: "") }
    var address by remember { mutableStateOf(company?.address ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(16.dp)) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    if (company == null) "إضافة شركة موردة جديدة" else "تعديل تفاصيل الشركة الموردة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الشركة") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم الهاتف") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("عنوان المقر") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (company != null && onDelete != null) {
                        Button(
                            onClick = { onDelete(company) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(0.8f)
                        ) {
                            Text("حذف")
                        }
                    }
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("إلغاء")
                    }
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                onSave(Company(id = company?.id ?: 0, name = name, phone = phone, address = address))
                            }
                        },
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("save_company_button")
                    ) {
                        Text("حفظ")
                    }
                }
            }
        }
    }
}

// --- SCREEN 5: REPORTS & BACKUPS (التقارير والنسخ) ---
@Composable
fun ReportsScreen(viewModel: PharmacyViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val invoices by viewModel.allInvoices.collectAsState()
    var selectedInvoiceDetail by remember { mutableStateOf<Invoice?>(null) }
    var activeInvoiceItems by remember { mutableStateOf<List<InvoiceItem>>(emptyList()) }

    // Backup restore launchers
    val backupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            val backupFile = DatabaseBackupHelper.backupDatabase(context)
            if (backupFile != null && backupFile.exists()) {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        backupFile.inputStream().use { input ->
                            input.copyTo(out)
                        }
                    }
                    Toast.makeText(context, "تم حفظ نسخة قاعدة البيانات بنجاح!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "فشل حفظ الملف!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val restoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                // Copy stream to temporary backup.db file
                val tempFile = File(context.cacheDir, "temp_restore.db")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    tempFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }

                // Restore database
                val success = DatabaseBackupHelper.restoreDatabase(context, tempFile)
                if (success) {
                    Toast.makeText(context, "تمت استعادة قاعدة البيانات بنجاح! يرجى إعادة تشغيل التطبيق.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "فشل استعادة قاعدة البيانات، تأكد من سلامة الملف!", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "حدث خطأ أثناء قراءة الملف!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Share / View file intents
    fun shareFile(file: File, mimeType: String) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة التقرير"))
        } catch (e: Exception) {
            Toast.makeText(context, "فشل مشاركة الملف!", Toast.LENGTH_SHORT).show()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Administrative Reports Buttons
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("التقارير الإدارية والتصدير", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.exportInventoryPdf { file ->
                                    if (file != null) {
                                        Toast.makeText(context, "تم توليد ملف PDF!", Toast.LENGTH_SHORT).show()
                                        shareFile(file, "application/pdf")
                                    } else {
                                        Toast.makeText(context, "فشل توليد التقرير!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("جرد المخزن (PDF)", fontSize = 12.sp)
                            }
                        }

                        Button(
                            onClick = {
                                viewModel.exportSalesCsv { file ->
                                    if (file != null) {
                                        Toast.makeText(context, "تم توليد تقرير CSV مبيعات الكاشير!", Toast.LENGTH_SHORT).show()
                                        shareFile(file, "text/csv")
                                    } else {
                                        Toast.makeText(context, "فشل توليد التقرير!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.GridOn, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("تقرير المبيعات (CSV)", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Database backups and restore section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("النسخ الاحتياطي والأمان", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("يمكنك تصدير ملف قاعدة البيانات بالكامل (.db) لحفظ مبيعاتك واستعادتها بأي وقت.", fontSize = 12.sp, color = Color.Gray)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                backupLauncher.launch("pharmacy_backup_${System.currentTimeMillis()}.db")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("تصدير نسخة احتياطية", fontSize = 12.sp)
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                restoreLauncher.launch(arrayOf("application/octet-stream", "*/*"))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.SettingsBackupRestore, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("استعادة قاعدة البيانات", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Invoice History Header
        item {
            Text("تاريخ الفواتير المبيعة", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
        }

        // History invoices list
        if (invoices.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("لا توجد فواتير مبيعة مسبقاً", color = Color.Gray)
                }
            }
        } else {
            items(invoices) { invoice ->
                val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
                val formattedDate = sdf.format(Date(invoice.timestamp))
                
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            selectedInvoiceDetail = invoice
                            // Fetch items flow asynchronously
                            scope.launch {
                                viewModel
                                    .exportSalesCsv { } // empty callback, but let's query db items
                                viewModel
                                    .allInvoices.value
                                    .firstOrNull()
                                activeInvoiceItems = viewModel.allMedicines.value.map {
                                    InvoiceItem(0, invoice.id, it.id, it.tradeName, 1, it.salePrice, it.salePrice)
                                }
                                // Quick dynamic assign from DAO list
                                activeInvoiceItems = viewModel.getInvoiceItemsForInvoiceSync(invoice.id)
                            }
                        },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(12.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(invoice.invoiceNumber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(formattedDate, fontSize = 12.sp, color = Color.Gray)
                        }
                        Text(formatIqd(invoice.finalAmount), fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }

    // Invoice Detail Dialog
    if (selectedInvoiceDetail != null) {
        val invoice = selectedInvoiceDetail!!
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
        val formattedDate = sdf.format(Date(invoice.timestamp))

        Dialog(onDismissRequest = { selectedInvoiceDetail = null }) {
            Card(shape = RoundedCornerShape(16.dp)) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("تفاصيل الفاتورة: ${invoice.invoiceNumber}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("تاريخ ووقت الفاتورة: $formattedDate", fontSize = 12.sp, color = Color.Gray)
                    
                    Divider()

                    // Items Sold list
                    Text("المواد المباعة في الفاتورة:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    LazyColumn(
                        modifier = Modifier
                            .heightIn(max = 180.dp)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(activeInvoiceItems) { item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${item.medicineName} x ${item.quantity}", fontSize = 12.sp)
                                Text(formatIqd(item.subtotal), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Divider()

                    // Totals
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                            Text("الإجمالي الفرعي:", fontSize = 12.sp)
                            Text(formatIqd(invoice.totalAmount), fontSize = 12.sp)
                        }
                        if (invoice.discountAmount > 0) {
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Text("الخصم:", fontSize = 12.sp)
                                Text("- " + formatIqd(invoice.discountAmount), fontSize = 12.sp, color = Color.Red)
                            }
                        }
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                            Text("الصافي المدفوع:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(formatIqd(invoice.finalAmount), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { selectedInvoiceDetail = null },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إغلاق")
                        }
                        
                        Button(
                            onClick = {
                                viewModel.printReceipt(invoice.id) { success ->
                                    if (success) {
                                        Toast.makeText(context, "تمت إعادة طباعة الفاتورة!", Toast.LENGTH_SHORT).show()
                                        selectedInvoiceDetail = null
                                    } else {
                                        Toast.makeText(context, "فشل الاتصال بالطابعة!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.weight(1.2f)
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("إعادة طباعة")
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Bluetooth Printer Setup Dialog ---
@Composable
fun PrinterConfigDialog(
    viewModel: PharmacyViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val pairedPrinters by viewModel.pairedPrinters.collectAsState()
    val selectedPrinterMac by viewModel.selectedPrinterMac.collectAsState()

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("إعدادات طابعة البلوتوث الحرارية", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    IconButton(onClick = { viewModel.loadPrinters() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث")
                    }
                }

                Text(
                    text = "يرجى إقران الطابعة الحرارية الصغيرة (58mm أو 80mm) أولاً عبر إعدادات بلوتوث الهاتف، ثم اختيارها أدناه كطابعة افتراضية:",
                    fontSize = 12.sp,
                    color = Color.Gray
                )

                if (pairedPrinters.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("لا يوجد أجهزة بلوتوث مقترنة بالموبايل!", color = Color.Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 200.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(pairedPrinters) { device ->
                            val isSelected = device.address == selectedPrinterMac
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.selectPrinter(device.address) },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ),
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(12.dp)
                                        .fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(device.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(device.address, fontSize = 11.sp, color = Color.Gray)
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = "نشط", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("إغلاق وحفظ")
                }
            }
        }
    }
}

// Utility formatting
private fun formatIqd(value: Double): String {
    return String.format(Locale.US, "%,.0f د.ع", value)
}
