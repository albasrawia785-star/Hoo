package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "medicines",
    foreignKeys = [
        ForeignKey(
            entity = Company::class,
            parentColumns = ["id"],
            childColumns = ["companyId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["barcode"], unique = false) // Allow non-unique or empty barcodes gracefully
    ]
)
data class Medicine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tradeName: String,       // الاسم التجاري
    val scientificName: String,  // الاسم العلمي
    val barcode: String = "",    // الباركود
    val purchasePrice: Double,   // سعر الشراء بالدينار
    val salePrice: Double,       // سعر البيع بالدينار
    val stockQuantity: Int,      // الكمية في المخزن
    val minStockLimit: Int = 5,  // الحد الأدنى للمخزون للتنبيه
    val expiryDate: String,      // تاريخ الصلاحية (DD/MM/YYYY)
    val expiryTimestamp: Long,   // الطابع الزمني لانتهاء الصلاحية للمقارنات
    val companyId: Long? = null  // الشركة الموردة
)
