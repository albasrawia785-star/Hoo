import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { Debtor, DebtorTransaction, InstallmentRecord, InstallmentPayment, Supplier, SupplierTransaction, AppSettings } from '../types';
import { getIdbDebtors, saveIdbDebtors, getIdbInstallments, saveIdbInstallments, getIdbSuppliers, saveIdbSuppliers } from './idb';
import { getLocalDebtors, setLocalDebtors, getLocalInstallments, setLocalInstallments, getLocalSuppliers, setLocalSuppliers } from './turso';

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const driveAuth = getAuth(app);

const DRIVE_SCOPES = [
  'https://www.googleapis.com/auth/drive.appdata',
  'https://www.googleapis.com/auth/drive.file',
];

const BACKUP_FILENAME = 'daftardebts_ledger_v2.json';

export type DriveSyncStatus = 'disabled' | 'idle' | 'syncing' | 'synced' | 'offline_queued' | 'error';

let cachedAccessToken: string | null = null;
let currentDriveUser: FirebaseUser | null = null;
let syncStatus: DriveSyncStatus = 'disabled';
let syncStatusListeners: Array<(status: DriveSyncStatus, lastSyncedAt?: string | null) => void> = [];
let lastSyncedAt: string | null = null;
let debounceTimer: ReturnType<typeof setTimeout> | null = null;
let isSyncing = false;

// Register status listener
export function subscribeDriveSyncStatus(
  listener: (status: DriveSyncStatus, lastSyncedAt?: string | null) => void
) {
  syncStatusListeners.push(listener);
  listener(syncStatus, lastSyncedAt);
  return () => {
    syncStatusListeners = syncStatusListeners.filter((l) => l !== listener);
  };
}

function notifyStatus(status: DriveSyncStatus) {
  syncStatus = status;
  syncStatusListeners.forEach((l) => l(syncStatus, lastSyncedAt));
}

export function getDriveSyncStatus() {
  return { status: syncStatus, lastSyncedAt, user: currentDriveUser };
}

/**
 * Initialize Drive Auth listener
 */
export function initGoogleDriveAuth(
  onUserChanged?: (user: FirebaseUser | null) => void
) {
  return onAuthStateChanged(driveAuth, async (user) => {
    currentDriveUser = user;
    const isEnabled = localStorage.getItem('gdrive_sync_enabled') === 'true';
    if (user && isEnabled) {
      notifyStatus('idle');
    } else {
      cachedAccessToken = null;
      notifyStatus('disabled');
    }
    if (onUserChanged) onUserChanged(user);
  });
}

/**
 * Sign in with Google Drive OAuth popup
 */
export async function signInGoogleDrive(): Promise<{ user: FirebaseUser; accessToken: string } | null> {
  try {
    notifyStatus('syncing');
    const provider = new GoogleAuthProvider();
    DRIVE_SCOPES.forEach((scope) => provider.addScope(scope));

    const result = await signInWithPopup(driveAuth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    
    if (!credential?.accessToken) {
      throw new Error('لم نتمكن من الحصول على تصريح الوصول لـ Google Drive');
    }

    cachedAccessToken = credential.accessToken;
    currentDriveUser = result.user;

    // Store marker in localStorage that user enabled Drive sync
    localStorage.setItem('gdrive_sync_enabled', 'true');
    notifyStatus('idle');

    return { user: result.user, accessToken: cachedAccessToken };
  } catch (err: any) {
    if (
      err?.code === 'auth/popup-closed-by-user' ||
      err?.code === 'auth/cancelled-popup-request' ||
      err?.message?.includes('popup-closed-by-user') ||
      err?.message?.includes('cancelled-popup-request')
    ) {
      console.warn('[GoogleDriveSync] Sign-in popup cancelled or closed by user');
      notifyStatus('disabled');
      return null;
    }
    console.error('[GoogleDriveSync] Sign in error:', err?.message || err);
    notifyStatus('error');
    return null;
  }
}

/**
 * Disconnect Google Drive
 */
export async function signOutGoogleDrive() {
  try {
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    cachedAccessToken = null;
    currentDriveUser = null;
    localStorage.removeItem('gdrive_sync_enabled');
    notifyStatus('disabled');
    await driveAuth.signOut().catch(() => {});
  } catch (err) {
    console.error('[GoogleDriveSync] Sign out error:', err);
    localStorage.removeItem('gdrive_sync_enabled');
    notifyStatus('disabled');
  }
}

/**
 * Find existing backup file in Google Drive AppData
 */
async function findBackupFileInDrive(token: string): Promise<{ id: string; name: string } | null> {
  try {
    const q = encodeURIComponent(`name = '${BACKUP_FILENAME}' and trashed = false`);
    const url = `https://www.googleapis.com/drive/v3/files?q=${q}&spaces=appDataFolder,drive&fields=files(id,name,modifiedTime)`;
    
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) return null;
    const data = await res.json();
    if (data.files && data.files.length > 0) {
      return data.files[0];
    }
    return null;
  } catch (err) {
    console.warn('[GoogleDriveSync] findBackupFile error:', err);
    return null;
  }
}

/**
 * Download backup JSON from Google Drive
 */
async function downloadBackupFromDrive(token: string, fileId: string): Promise<any | null> {
  try {
    const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.warn('[GoogleDriveSync] downloadBackup error:', err);
    return null;
  }
}

/**
 * Create or update backup JSON in Google Drive
 */
async function uploadBackupToDrive(token: string, fileData: any, existingFileId?: string | null): Promise<string | null> {
  try {
    const metadata = {
      name: BACKUP_FILENAME,
      mimeType: 'application/json',
      parents: existingFileId ? undefined : ['appDataFolder'],
    };

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      'Content-Type: application/json\r\n\r\n' +
      JSON.stringify(fileData) +
      closeDelimiter;

    let url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
    let method = 'POST';

    if (existingFileId) {
      url = `https://www.googleapis.com/upload/drive/v3/files/${existingFileId}?uploadType=multipart`;
      method = 'PATCH';
    }

    const res = await fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartRequestBody,
    });

    if (!res.ok) {
      console.warn('[GoogleDriveSync] Upload failed status:', res.status);
      return null;
    }

    const json = await res.json();
    return json.id || existingFileId || null;
  } catch (err) {
    console.error('[GoogleDriveSync] uploadBackup error:', err);
    return null;
  }
}

// ----------------------------------------------------
// CRDT / Deterministic Event Sourcing Ledger Merger
// ----------------------------------------------------

export interface LedgerSyncPayload {
  version: number;
  lastUpdated: string;
  deviceId: string;
  userId: number;
  debtors: Debtor[];
  installments: InstallmentRecord[];
  suppliers: Supplier[];
}

/**
 * Deterministically merges local and remote ledger data.
 * Solves offline concurrent transactions from multiple devices on the same debtor/installment/supplier!
 */
export function mergeLedgerData(
  local: { debtors: Debtor[]; installments: InstallmentRecord[]; suppliers: Supplier[] },
  remote: { debtors: Debtor[]; installments: InstallmentRecord[]; suppliers: Supplier[] }
): { mergedDebtors: Debtor[]; mergedInstallments: InstallmentRecord[]; mergedSuppliers: Supplier[] } {
  
  // 1. Merge Debtors
  const debtorMap = new Map<number, { local?: Debtor; remote?: Debtor }>();
  (local.debtors || []).forEach((d) => debtorMap.set(d.id, { ...debtorMap.get(d.id), local: d }));
  (remote.debtors || []).forEach((d) => debtorMap.set(d.id, { ...debtorMap.get(d.id), remote: d }));

  const mergedDebtors: Debtor[] = [];

  debtorMap.forEach(({ local: l, remote: r }, id) => {
    if (l && !r) {
      mergedDebtors.push(l);
      return;
    }
    if (!l && r) {
      mergedDebtors.push(r);
      return;
    }
    if (l && r) {
      // Both exist! Merge transaction histories by unique transaction ID
      const txMap = new Map<string, DebtorTransaction>();
      (l.history || []).forEach((tx) => {
        const key = tx.id || `tx_${tx.type}_${tx.date}_${tx.amount}`;
        txMap.set(key, tx);
      });
      (r.history || []).forEach((tx) => {
        const key = tx.id || `tx_${tx.type}_${tx.date}_${tx.amount}`;
        if (!txMap.has(key)) {
          txMap.set(key, tx);
        }
      });

      const mergedHistory = Array.from(txMap.values()).sort((a, b) => {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      });

      // Deterministically recalculate total amount from merged transactions
      let computedAmount = 0;
      mergedHistory.forEach((tx) => {
        if (tx.type === 'initial' || tx.type === 'add') {
          computedAmount += Number(tx.amount || 0);
        } else if (tx.type === 'pay') {
          computedAmount -= Number(tx.amount || 0);
        }
      });
      if (computedAmount < 0) computedAmount = 0;

      mergedDebtors.push({
        id,
        name: l.name || r.name,
        phone: l.phone || r.phone,
        amount: computedAmount,
        status: computedAmount <= 0 ? 'مسدد' : 'مستمر',
        userId: l.userId || r.userId,
        createdAt: l.createdAt || r.createdAt,
        lastDebtDate: l.lastDebtDate || r.lastDebtDate,
        notes: l.notes || r.notes,
        history: mergedHistory,
        type: l.type || r.type || 'debtor',
      });
    }
  });

  // 2. Merge Installments
  const instMap = new Map<number, { local?: InstallmentRecord; remote?: InstallmentRecord }>();
  (local.installments || []).forEach((inst) => instMap.set(inst.id, { ...instMap.get(inst.id), local: inst }));
  (remote.installments || []).forEach((inst) => instMap.set(inst.id, { ...instMap.get(inst.id), remote: inst }));

  const mergedInstallments: InstallmentRecord[] = [];

  instMap.forEach(({ local: l, remote: r }, id) => {
    if (l && !r) {
      mergedInstallments.push(l);
      return;
    }
    if (!l && r) {
      mergedInstallments.push(r);
      return;
    }
    if (l && r) {
      // Merge payment records
      const payMap = new Map<string, InstallmentPayment>();
      (l.payments || []).forEach((p) => {
        const key = p.id || `pay_${p.date}_${p.amount}`;
        payMap.set(key, p);
      });
      (r.payments || []).forEach((p) => {
        const key = p.id || `pay_${p.date}_${p.amount}`;
        if (!payMap.has(key)) {
          payMap.set(key, p);
        }
      });

      const mergedPayments = Array.from(payMap.values()).sort((a, b) => {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      });

      const totalAmount = Number(l.totalAmount || r.totalAmount || 0);
      const downPayment = Number(l.downPayment || r.downPayment || 0);
      const totalPaid = mergedPayments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
      const remainingAmount = Math.max(0, totalAmount - downPayment - totalPaid);

      mergedInstallments.push({
        id,
        name: l.name || r.name,
        phone: l.phone || r.phone,
        item: l.item || r.item,
        totalAmount,
        downPayment,
        remainingAmount,
        monthlyInstallmentAmount: l.monthlyInstallmentAmount || r.monthlyInstallmentAmount,
        registrationDate: l.registrationDate || r.registrationDate,
        nextDueDate: l.nextDueDate || r.nextDueDate,
        userId: l.userId || r.userId,
        status: remainingAmount <= 0 ? 'completed' : l.status || r.status,
        notes: l.notes || r.notes,
        payments: mergedPayments,
        createdAt: l.createdAt || r.createdAt,
      });
    }
  });

  // 3. Merge Suppliers
  const suppMap = new Map<number, { local?: Supplier; remote?: Supplier }>();
  (local.suppliers || []).forEach((s) => suppMap.set(s.id, { ...suppMap.get(s.id), local: s }));
  (remote.suppliers || []).forEach((s) => suppMap.set(s.id, { ...suppMap.get(s.id), remote: s }));

  const mergedSuppliers: Supplier[] = [];

  suppMap.forEach(({ local: l, remote: r }, id) => {
    if (l && !r) {
      mergedSuppliers.push(l);
      return;
    }
    if (!l && r) {
      mergedSuppliers.push(r);
      return;
    }
    if (l && r) {
      const txMap = new Map<string, SupplierTransaction>();
      (l.history || []).forEach((tx) => {
        const key = tx.id || `supp_tx_${tx.type}_${tx.date}_${tx.amount}`;
        txMap.set(key, tx);
      });
      (r.history || []).forEach((tx) => {
        const key = tx.id || `supp_tx_${tx.type}_${tx.date}_${tx.amount}`;
        if (!txMap.has(key)) {
          txMap.set(key, tx);
        }
      });

      const mergedHistory = Array.from(txMap.values()).sort((a, b) => {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      });

      let computedAmount = 0;
      mergedHistory.forEach((tx) => {
        if (tx.type === 'debt' || tx.type === 'initial' || tx.type === 'add_debt') {
          computedAmount += Number(tx.amount || 0);
        } else if (tx.type === 'pay' || tx.type === 'pay_supplier') {
          computedAmount -= Number(tx.amount || 0);
        }
      });
      if (computedAmount < 0) computedAmount = 0;

      mergedSuppliers.push({
        id,
        name: l.name || r.name,
        companyName: l.companyName || r.companyName,
        phone: l.phone || r.phone,
        notes: l.notes || r.notes,
        amount: computedAmount,
        createdAt: l.createdAt || r.createdAt,
        updatedAt: l.updatedAt || r.updatedAt,
        history: mergedHistory,
        userId: l.userId || r.userId,
        itemType: l.itemType || r.itemType,
        status: l.status || r.status,
        lastTransactionDate: l.lastTransactionDate || r.lastTransactionDate,
      });
    }
  });

  return { mergedDebtors, mergedInstallments, mergedSuppliers };
}

/**
 * Trigger background debounced Google Drive auto-sync.
 * Merges local and remote states without data loss.
 */
export function triggerGoogleDriveAutoSync(
  userId: number,
  localData: { debtors: Debtor[]; installments: InstallmentRecord[]; suppliers: Supplier[] },
  onDataMerged?: (merged: { debtors: Debtor[]; installments: InstallmentRecord[]; suppliers: Supplier[] }) => void
) {
  const isEnabled = localStorage.getItem('gdrive_sync_enabled') === 'true';
  if (!isEnabled) return;

  if (debounceTimer) clearTimeout(debounceTimer);

  debounceTimer = setTimeout(async () => {
    if (isSyncing) return;
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      notifyStatus('offline_queued');
      return;
    }

    isSyncing = true;
    notifyStatus('syncing');

    try {
      // Check if access token is available (never trigger background popups)
      if (!cachedAccessToken) {
        notifyStatus(driveAuth.currentUser ? 'idle' : 'disabled');
        isSyncing = false;
        return;
      }

      if (!cachedAccessToken) {
        notifyStatus('idle');
        isSyncing = false;
        return;
      }

      // 1. Check if backup file exists in Drive
      const fileInfo = await findBackupFileInDrive(cachedAccessToken);
      let fileId = fileInfo?.id || null;

      let remoteData: { debtors: Debtor[]; installments: InstallmentRecord[]; suppliers: Supplier[] } = {
        debtors: [],
        installments: [],
        suppliers: [],
      };

      if (fileId) {
        const downloaded = await downloadBackupFromDrive(cachedAccessToken, fileId);
        if (downloaded) {
          remoteData = {
            debtors: downloaded.debtors || [],
            installments: downloaded.installments || [],
            suppliers: downloaded.suppliers || [],
          };
        }
      }

      // 2. CRDT Event-sourcing Merge
      const { mergedDebtors, mergedInstallments, mergedSuppliers } = mergeLedgerData(localData, remoteData);

      // 3. Save merged data locally if remote had new data
      await saveIdbDebtors(userId, mergedDebtors);
      setLocalDebtors(userId, mergedDebtors);

      await saveIdbInstallments(userId, mergedInstallments);
      setLocalInstallments(userId, mergedInstallments);

      await saveIdbSuppliers(userId, mergedSuppliers);
      setLocalSuppliers(userId, mergedSuppliers);

      if (onDataMerged) {
        onDataMerged({
          debtors: mergedDebtors,
          installments: mergedInstallments,
          suppliers: mergedSuppliers,
        });
      }

      // 4. Upload merged state back to Drive
      const payload: LedgerSyncPayload = {
        version: 2,
        lastUpdated: new Date().toISOString(),
        deviceId: `dev_${Math.random().toString(36).substring(2, 9)}`,
        userId,
        debtors: mergedDebtors,
        installments: mergedInstallments,
        suppliers: mergedSuppliers,
      };

      const newFileId = await uploadBackupToDrive(cachedAccessToken, payload, fileId);
      if (newFileId) {
        lastSyncedAt = new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' });
        notifyStatus('synced');
      } else {
        notifyStatus('idle');
      }
    } catch (err) {
      console.error('[GoogleDriveSync] Auto sync error:', err);
      notifyStatus('error');
    } finally {
      isSyncing = false;
    }
  }, 1500);
}

// Online reconnection listener
if (typeof window !== 'undefined') {
  window.addEventListener('online', () => {
    if (localStorage.getItem('gdrive_sync_enabled') === 'true') {
      const session = JSON.parse(localStorage.getItem('user_session') || '{}');
      if (session && session.id) {
        const localDebtors = getLocalDebtors(session.id) || [];
        const localInstallments = getLocalInstallments(session.id) || [];
        const localSuppliers = getLocalSuppliers(session.id) || [];
        triggerGoogleDriveAutoSync(session.id, {
          debtors: localDebtors,
          installments: localInstallments,
          suppliers: localSuppliers,
        });
      }
    }
  });
}
